public class Average
{
    public static double averageArea(Shape []shapes)
    {
        double sum = 0;
        int count = 0;
        
        for(int i = 0; i < shapes.length; i += 1)
        {
            sum += shapes[i].area();
            count += 1;
        }
         
        return sum / count;
         
    }
}
