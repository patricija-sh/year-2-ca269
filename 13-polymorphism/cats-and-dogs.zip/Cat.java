class Cat extends Animal
{
    public Cat(String n)
    {
        super(n);
    }
    
    public String hello()
    {
        return "Meow";
    }
    
}