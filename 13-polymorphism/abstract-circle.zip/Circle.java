import static java.lang.Math.*;

public class Circle extends Shape
{
    double radius;
    public Circle(String n, double r)
    {
        super(n);
        this.radius = r;
    }
    
    public double area()
    {
        return PI * (radius * radius);
    }
}