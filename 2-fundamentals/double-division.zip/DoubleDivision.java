import java.util.Scanner;

public class DoubleDivision
{
    // Fill in the main method
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        
        // Ask the user to enter a number
        System.out.print("Please enter two floating point numbers: ");
        
        // Read in the numbers (you need a variable and an in.nextInt() call for each integer)
        double num1 = in.nextDouble();
        double num2 = in.nextDouble();

        // do the necessary (calculate the result) (Create a variable to hold the result - what type should the variable be?)
        double numsDivided = num1 / num2;

        // prepare the user for the result
        System.out.println(num1 + " / " + num2 + " is " + numsDivided);
    }
}