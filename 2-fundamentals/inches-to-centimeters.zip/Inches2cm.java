import java.util.Scanner;

public class Inches2cm
{
    public static void main(String [] args)
    {
        // Create a scanner object
        Scanner in = new Scanner(System.in);
        
        // Ask the user to enter a number
        System.out.print("Please enter a quantity in inches: ");
        
        // Read in the number.
        int toConvert = in.nextInt();
        
        // Find out how many inches (use a whole number for integers) - 1 inch is 2.54 cm
        double conversionMetric = 2.54;
        double converted = toConvert * conversionMetric;

        // Print out the result
        System.out.println( toConvert + " inch is " + converted + " cm");
    }
}