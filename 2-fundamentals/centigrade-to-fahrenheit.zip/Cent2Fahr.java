import java.util.Scanner;

public class Cent2Fahr
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);

        // Read in the number
        int num1 = in.nextInt();

        // do the necessary (calculate the result) (Create a variable to hold the result - what type should the variable be?)
        double cent2fahr = (num1 * 1.8) + 32;

        // print out the result (use System.out.println() )
        System.out.println(num1 + " " + cent2fahr);

    }
}