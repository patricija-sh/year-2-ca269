import java.util.Scanner;

public class Reverse
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("How many numbers: ");
        int num = in.nextInt();  // how many inputs will there be
        
        // Create an array
        int numbers[];
        numbers = new int[num];  // allocating memory to array
        
        System.out.print("Enter " + num + " numbers: ");
        
        int i = 0;
        while(i < num)
        {
            numbers[i] = in.nextInt();
            i += 1;
        }
        
        
        System.out.print("The numbers reversed are:");
        
        // Reversing the numbers
        i = 0;
        while(i < num)
        {
            System.out.print(" " + numbers[num - i - 1]);
            i += 1;
        }
        
        System.out.println();
    }
}