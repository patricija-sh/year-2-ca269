//
// Supplied code to help ensure there will be no output formatting issues.
//
import java.util.Scanner;

public class AboveAverage
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("How many numbers: ");
        int num = in.nextInt();
        double average = 0;
        double sum = 0;
        
        // Create an array
        double numbers[];
        numbers = new double[num];  // allocating memory to array
        
        System.out.print("Enter " + num + " numbers: ");

        // Now read in the numbers
        int i = 0;
        while(i < num)
        {
            numbers[i] = in.nextDouble();
            sum += numbers[i];
            i += 1;
        }
        
        average = sum / num;
        
        
        // Print out the numbers greater than the average
        System.out.println("The above average numbers are:");
        
        i = 0;
        while(i < num)
        {
            if(numbers[i] > average)
            {
                System.out.print(" " + numbers[i]); // You may want to put this in a loop.
            }
            
            i += 1;
        }
    

        System.out.println(); // Should finish with a new line
    }
}