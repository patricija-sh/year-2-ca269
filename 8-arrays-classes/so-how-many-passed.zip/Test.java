public class Test
{
    public static int numberPasses(Student [] student)
    {
        int passed = 0;
        
        for(int i = 0; i < student.length; i++)
        if(student[i].getMark() >= 40)
        {
            passed += 1;
        }
        return passed;
    }
}