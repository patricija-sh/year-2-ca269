
public class Test
{
    public static double getPassingAverage(Student [] student)
    {
        double sum = 0;
        int pass_count = 0;
        
        for(int i = 0; i < student.length; i++)
        {
            if(student[i].getMark() >= 40)
            {
                pass_count++;
                sum += student[i].getMark();
            }
        }
        return sum/pass_count;
    }
}