public class Test
{
    // Create a static method called countEven which returns the number of even numbers in the array
    static int countEven(int array[])
    {
        int even_counter = 0;
        
        int i = 0;
        while(i < array.length)
        {
            if(array[i] % 2 == 0)
            {
                even_counter += 1;
            }
            i += 1;
        }
        
        return even_counter;
    }
}