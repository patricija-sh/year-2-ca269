public class Test
{
    // Create a static method called countFives which returns the number of fives in the array
    static int countFives(int array[])
    {
        int counter = 0;
        
        int i = 0;
        while(i < array.length)
        {
            if(array[i] == 5)
            {
                counter += 1;
            }
            
            i += 1;
        }
        
        return counter;
    }
}