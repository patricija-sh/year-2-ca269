public class Test
{
    // Create a static method called getSum which sums an array of ints
    static int getSum(int array[])
    {
        int sum = 0;
        
        int i = 0;
        while(i < array.length)
        {
            sum += array[i];
            i += 1;
        }
        
        return sum;
    }
}