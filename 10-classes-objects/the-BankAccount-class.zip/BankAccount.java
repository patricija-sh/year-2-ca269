public class BankAccount
{
    double balance = 0.00;
}