public class BankAccount
{
    double balance = 100;
    
    // public BankAccount(double initial_amount)
    // {
    //   balance = initial_amount;
    // }
    
    public double withdraw(double amount)
    {
        balance -= amount;
        return balance;
    }
    
    public double deposit(double amount)
    {
        balance += amount;
        return balance;
    }
    
    public String toString()
    {
        return "The balance is " + balance;
    }
    
}