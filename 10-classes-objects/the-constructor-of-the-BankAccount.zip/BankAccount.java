public class BankAccount
{
    double balance = 0.00;
    
    public BankAccount(double initial_amount)
    {
       balance = initial_amount;
    }
}