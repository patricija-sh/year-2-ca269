/*
    This code is supplied and may be used to help solve this problem.
*/
import java.util.Scanner;

public class SplitWord
{
    public static void main(String [] args)
    {
        // Create a scanner object
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter a word: ");
        // Read in the word
        String word = in.next();
        
        // YOUR CODE HERE
        if(word.length() % 2 == 1)
        {
            int i = 2;
        }
        int i = 1;
        for(; i < word.length(); i += 1)
        {
            System.out.println(word.substring(i - 1, i + 1));
        }
        
    }
}