import java.util.Scanner;

public class FirstMiddleLast
{
    public static void main(String[] arg)
    {
        Scanner in = new Scanner(System.in);  
        System.out.print("Enter a word: ");
        String input = in.next();
        int length = input.length();
        
        System.out.println(input.substring(0, 1));
        System.out.println(input.substring(1, length - 1));
        System.out.println(input.substring(length - 1));
    }
}