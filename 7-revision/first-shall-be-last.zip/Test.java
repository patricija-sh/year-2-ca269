public class Test
{
    // This method returns a String and receives a String
    public static String firstShallBeLast(String word)
    {
        // Reorganise the string.  Remember the '+' operator concatenates strings.
        // Needs to return the correct string.
        char first = word.charAt(0);
        char last = word.charAt(word.length() - 1);
        String middle = word.substring(1, word.length() - 1);
        
        return last + middle + first;
        
    }
}