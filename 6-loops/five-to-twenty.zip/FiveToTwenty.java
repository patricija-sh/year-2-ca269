public class FiveToTwenty
{
    public static void main(String [] args)
    {
        // Use a loop to print out the numbers
        int i = 4;
        while(i < 20)
        {
            System.out.print(i + 1 + " ");
            i += 1;
        }
       
        System.out.println(); // Finish with a new line.
    }
}