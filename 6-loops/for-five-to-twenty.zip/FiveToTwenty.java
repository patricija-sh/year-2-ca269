public class FiveToTwenty
{
    public static void main(String [] args)
    {
        for(int i = 5; i <= 20; i++)
        {
            System.out.print(i + " ");
        }
        
        System.out.println();
    }
}