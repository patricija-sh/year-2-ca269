import java.util.Scanner;

public class HowManyNumbers
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter numbers: ");
        int next = in.nextInt();
        int counter = 0;
        
        while(next != -1)
        {   counter++;
            next = in.nextInt();
        }
        
        System.out.println(counter + " numbers were entered.");
    }
}