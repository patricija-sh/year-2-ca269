public class OneToTen
{
    public static void main(String [] args)
    {
        // Use a for loop to print out the numbers.
        for(int i = 0; i < 10; i ++)
        {
            System.out.print(i + 1 + " ");
        }
        
        System.out.println();
    }
}