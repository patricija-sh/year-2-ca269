import java.util.Scanner;

public class NoMinusOne
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter numbers: ");
        int next = in.nextInt();
        int num = 0;
        
        while(next != -1)
        {   num = next;
            next = in.nextInt();
        }
        
        System.out.println("The penultimate number was: " + num);
    }
}