public class TenToOne
{
    public static void main(String [] args)
    {
        // Use a for loop to print out the numbers.
        for(int i = 10; i > 0; i --)
        {
            System.out.print(i + " ");
        }
        
        System.out.println();
    }
}