public class TenToOne
{
    public static void main(String [] args)
    {
        // Use a loop to print out the numbers
        int i = 10;
        while(i > 0)
        {
            System.out.print(i + " ");
            i -= 1;
        }
       
        System.out.println(); // Finish with a new line.
    }
}