// Create a Word class with one static method called containsLetter

public class Word
{
    static boolean containsLetter(String word, char letter)
    {
        
        int i = 0;
        while(i < word.length())
        {
            if(word.charAt(i) == letter)
            {
                return true;
            }
            i += 1;
        }
        
        return false;
    }
}