// Create a Word class with one static method called showLetters

public class Word
{
    static boolean containsLetter(String word, char letter)
    {
        
        int i = 0;
        while(i < word.length())
        {
            if(word.charAt(i) == letter)
            {
                return true;
            }
            i += 1;
        }
        
        return false;
    }
    
    static String showLetters(String word, String letters)
    {
        char[] outchars = new char[word.length()];
        
        for(int i = 0; i < word.length(); i++)
        {
            outchars[i] = '_';
        }
        
        for(int i = 0; i < letters.length(); i++)
        {
            if(Word.containsLetter(word, letters.charAt(i)))
            {
                int j = 0;
                while(j < word.length())
                {
                    if(word.charAt(j) == letters.charAt(i))
                    {
                        outchars[j] = letters.charAt(i); 
                    }
                    j += 1;
                }
            }
        }
        
        String output = new String(outchars);
        
        return output;
    }
    
}