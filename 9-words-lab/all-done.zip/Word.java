// Create a Word class with a static method called allDone

public class Word
{
    
    static boolean containsLetter(String word, char letter)
    {
        
        int i = 0;
        while(i < word.length())
        {
            if(word.charAt(i) == letter)
            {
                return true;
            }
            i += 1;
        }
        
        return false;
    }
    
    static boolean allDone(String word, String guesses)
    {
        int counter = 0;
        
        int i = 0;
        while(i < word.length())
        {
            if(Word.containsLetter(guesses, word.charAt(i)))
            {
                counter += 1;
            }
            i += 1;
        }
        
        if(counter == word.length())
        {
            return true;
        }
        return false;
    }
}