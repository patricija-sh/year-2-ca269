// Create a Word class with one static method called showLetter

public class Word
{
    static boolean containsLetter(String word, char letter)
    {
        
        int i = 0;
        while(i < word.length())
        {
            if(word.charAt(i) == letter)
            {
                return true;
            }
            i += 1;
        }
        
        return false;
    }
    
    static String showLetter(String word, char letter)
    {
        String output_word = "";
        
        if(Word.containsLetter(word, letter))
        {
            int i = 0;
            while(i < word.length())
            {
                if(word.charAt(i) != letter)
                {
                    output_word += "_";
                }
                else
                {
                   output_word += letter;  
                }
                i += 1;
            }
        }
        else
        {
            int i = 0;
            while(i < word.length())
            {
                output_word += "_";
            }
        }
        
        return output_word;
    }
    
}