import java.util.Scanner;

public class TellMeAboutYourself
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Tell me your name: ");
        String name = in.next();
        int age = in.nextInt();
        String favColour = in.next();
        
        System.out.print(name + " what is your age and what is your favourite colour?");
        System.out.println("Hello " + name + ", you are " + age + " and your favourite colour is " + favColour+ ".");
    }
}