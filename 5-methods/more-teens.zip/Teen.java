public class Teen
{
    static boolean isTeenager(int age)
    {
        boolean isTeenager;
		isTeenager = age > 12 && age < 20;
	    
	    if (isTeenager)
	    {
	        return true;
	    }
	    else
	    {
	        return false;
	    }
    }
}