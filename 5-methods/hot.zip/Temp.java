import java.util.Scanner;

/*
    Create a class with a main method.
    The method should read in a Fahrenhit Temperature
    Get the equivalent in Celsius (using the fahr2cels() method
    and print out the result.
*/
public class Temp
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Give me a Fahrenheit temperature: ");
        double temp = in.nextDouble();
        
        temp = Convert.fahr2cels(temp);
        
        System.out.println("In Celsius that would be: " + temp);
    }
}