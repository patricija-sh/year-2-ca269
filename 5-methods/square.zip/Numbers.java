public class Numbers
{
    // This class needs only one static method which has an int parameter and which returns an int.
    // The method should be called square and it should return the square of its parameter.
    static int square(int x)
    {
        return x * x;
    }
}