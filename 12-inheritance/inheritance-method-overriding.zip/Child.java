public class Child extends Parent
{
    public int makeATwo()
    {
        return 3;
    }
}