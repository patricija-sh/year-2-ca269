public class Animal
{
    String name;
    
    public Animal(String name)
    {
        this.name = name;
    }
    
    public String greeting()
    {
        return "Hello, my name is " + name;
    }

}
