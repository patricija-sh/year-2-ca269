// An abstract Animal class
// and a method called greeting which returns a String.

public abstract class Animal
{
    public abstract String greeting();
}