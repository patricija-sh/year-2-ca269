public class ExceptionMaker
{
    public static void main(String [] args)
    {
        throw new ArrayIndexOutOfBoundsException("Exception caught");
    }
}