public class ReverseArgs
{
    public static void main(String [] args)
    {
        int length = args.length;
        
        int i = 0;
        for(String s : args)
        {
            System.out.println("args[" + (length - i - 1) + "] = " + args[length - i - 1]);
            i += 1;
        }
        
    }
}