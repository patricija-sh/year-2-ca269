public class TotalArgs
{
    public static void main(String [] args)
    {
        int sum = 0;
        
        int i = 0;
        for(String s : args)
        {
            sum += Integer.parseInt(args[i]);
            i += 1;
        }
        
        System.out.println("The sum of all the args is " + sum + ".");
        
    }
}