public class Args
{
    public static void main(String [] args)
    {
        int i = 0;
        for(String s : args)
        {
            System.out.println("args[" + i + "] = " + args[i] );
            i += 1;
        }
    }
}